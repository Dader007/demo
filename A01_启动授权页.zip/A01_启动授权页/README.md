# Buyer A01 Combined Package

## Structure
This package follows the same combined structure as the reference example:
- main prototype files at the page root
- reusable PNG assets under `assets/png/`
- editable SVG assets under `assets/svg/`

## Files
- `A01_启动授权页.png` — bitmap prototype page
- `A01_启动授权页.svg` — editable SVG prototype page
- `A01_启动授权页_preview.png` — preview image
- `assets/png/` — reusable PNG resources
- `assets/svg/` — editable SVG resources
- `asset_manifest.json` — asset inventory

## Notes
- The SVG files are editable and suitable for Figma / Illustrator / Inkscape.
- The illustration SVGs are editable vector reconstructions for prototype and design use.
